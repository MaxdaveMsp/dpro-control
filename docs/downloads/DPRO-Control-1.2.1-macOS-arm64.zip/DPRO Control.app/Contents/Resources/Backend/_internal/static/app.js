'use strict';
const $ = selector => document.querySelector(selector);
const icons = {
  sliders:'<path d="M5 3v18M12 3v18M19 3v18"/><path d="M2 8h6M9 16h6M16 7h6"/>',
  network:'<rect x="8" y="3" width="8" height="6" rx="1"/><path d="M12 9v5M4 18v-4h16v4"/><rect x="1" y="18" width="6" height="3" rx=".5"/><rect x="9" y="18" width="6" height="3" rx=".5"/><rect x="17" y="18" width="6" height="3" rx=".5"/>',
  refresh:'<path d="M20 8a8 8 0 1 0 0 8M20 3v5h-5"/>',
  input:'<path d="M3 12h13m-5-5 5 5-5 5M17 4h4v16h-4"/>',
  output:'<path d="M8 12h13m-5-5 5 5-5 5M7 4H3v16h4"/>',
  link:'<path d="m10 14 4-4M8 16l-1 1a4 4 0 0 1-6-6l4-4a4 4 0 0 1 6 0m2 1 1-1a4 4 0 0 1 6 6l-4 4a4 4 0 0 1-6 0" transform="translate(1 0)"/>',
  check:'<path d="m8 12 3 3 5-6"/><circle cx="12" cy="12" r="9"/>',
  activity:'<path d="M2 12h4l3-8 5 16 3-8h5"/>',
  bolt:'<path d="m13 2-9 12h7l-1 8 10-13h-7z"/>',
  filter:'<path d="M3 18h4l7-12h7M3 6h4"/>',
  speaker:'<path d="M4 9h4l5-4v14l-5-4H4zM17 8a6 6 0 0 1 0 8M20 5a10 10 0 0 1 0 14"/>'
};
function icon(name){return `<span class="icon"><svg viewBox="0 0 24 24" aria-hidden="true">${icons[name] || icons.sliders}</svg></span>`;}
document.querySelectorAll('[data-icon]').forEach(el => el.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true">${icons[el.dataset.icon]}</svg>`);
let state = null, config = null, pending = false, toastTimer = null, editing = null;
function showWorkspace(view){
  const status=view==='status';
  $('#signal-groups').hidden=status;
  $('#overview-heading').hidden=status;
  $('#device-status').hidden=!status;
  $('#status-heading').hidden=!status;
  $('#workspace-title').textContent=status?'Device status':'Device overview';
  for(const [id,active] of [['overview-nav',!status],['status-nav',status]]){
    const button=$(`#${id}`);
    button.classList.toggle('active',active);
    button.querySelector('.nav-dot').hidden=!active;
    if(active)button.setAttribute('aria-current','page');else button.removeAttribute('aria-current');
  }
  window.scrollTo(0,0);
}
$('#overview-nav').addEventListener('click',()=>showWorkspace('overview'));
$('#status-nav').addEventListener('click',()=>showWorkspace('status'));


function dial(group, channel){
  const ticks = Array.from({length:19}, (_,i)=>{
    const a=(135+i*15)*Math.PI/180;
    return `<line class="dial-tick" x1="${83+70*Math.cos(a)}" y1="${75+70*Math.sin(a)}" x2="${83+74*Math.cos(a)}" y2="${75+74*Math.sin(a)}"/>`;
  }).join('');
  return `<div class="dial-wrap"><svg class="dial-svg" viewBox="0 0 166 157" aria-hidden="true">${ticks}<path class="dial-track" d="M37.038 120.962 A65 65 0 1 1 128.962 120.962"/><path id="arc-${group}-${channel}" class="dial-fill" pathLength="100" stroke-dasharray="0 100" d="M37.038 120.962 A65 65 0 1 1 128.962 120.962"/></svg><div class="dial-knob"><span class="parameter-value" id="value-${group}-${channel}">—</span><span class="parameter-unit">dB</span></div><div class="dial-label">${group==='input'?'PREAMP GAIN':'OUTPUT LEVEL'}</div></div>`;
}
let meterState = null;
function meter(group, channel){
  return `<div class="signal-meter" id="meter-${group}-${channel}"><div class="meter-heading"><span>SIGNAL <small class="meter-status">OFFLINE</small></span><strong class="meter-value">— <small>dBFS</small></strong></div><div class="meter-track" role="meter" aria-label="${group} ${channel} signal level in dBFS" aria-valuemin="-90" aria-valuemax="0" aria-valuetext="Unavailable"><div class="meter-color"></div><div class="meter-cover"></div></div><div class="meter-scale"><span>−90</span><span>−60</span><span>−30</span><span>0</span></div></div>`;
}
function renderMeters(data){
  meterState=data;
  ['input','output'].forEach((group,g)=>[1,2].forEach(ch=>{
    const element=$(`#meter-${group}-${ch}`), track=element.querySelector('.meter-track');
    const valid=data.valid && state?.connected;
    const level=valid?data.levels[g*2+ch-1]:null;
    element.classList.toggle('meter-live',!!valid);
    element.querySelector('.meter-status').textContent=(!state?.connected?'offline':data.status).toUpperCase();
    element.querySelector('.meter-value').innerHTML=`${level===null?'—':level<=-90?'≤−90':level.toFixed(1).replace('-','−')} <small>dBFS</small>`;
    element.style.setProperty('--meter-fill',`${level===null?0:(level+90)/90*100}%`);
    track.setAttribute('aria-valuetext',level===null?'Unavailable':`${level<=-90?'At or below ':''}${level} dBFS`);
    if(level===null)track.removeAttribute('aria-valuenow');else track.setAttribute('aria-valuenow',level);
  }));
}
async function pollMeters(){
  try{renderMeters(await fetchJSON('/api/meters',{signal:AbortSignal.timeout(1000)}));}
  catch(error){renderMeters({valid:false,status:'stale'});}
  setTimeout(pollMeters,document.hidden?300:100);
}
function card(group, channel){
  const input=group==='input', field=input?'gain':'level', max=input?66:255, step=input?3:1;
  return `<article class="channel-card ${group}" id="card-${group}-${channel}" aria-label="${group} channel ${channel}"><div class="channel-header"><div class="channel-identity"><span class="channel-number">0${channel}</span><div><div class="channel-name">${input?'Input':'Output'} ${channel}</div><div class="channel-direction">${input?'Analog → Dante':'Dante → Analog'}</div></div></div><span class="channel-state-dot" title="Device readback status"></span></div>${dial(group,channel)}<div class="parameter-controls"><div class="range-labels"><span>${input?'0 dB':'−127.5 dB'}</span><span id="range-state-${group}-${channel}">—</span><span>${input?'66 dB':'0 dB'}</span></div><input type="range" id="range-${group}-${channel}" aria-label="${input?'Input gain in dB':'Output level in dB'} channel ${channel}" data-group="${group}" data-channel="${channel}" data-field="${field}" min="0" max="${max}" step="${step}" value="0" disabled><div class="stepper"><button data-step="-${step}" data-group="${group}" data-channel="${channel}" data-field="${field}" aria-label="Decrease ${group} ${channel} ${field}" disabled>−</button><span>${input?'3 dB / STEP':'0.5 dB / STEP'}</span><button data-step="${step}" data-group="${group}" data-channel="${channel}" data-field="${field}" aria-label="Increase ${group} ${channel} ${field}" disabled>+</button></div></div>${meter(group,channel)}<div class="channel-settings">${input?`
  <div class="setting-row"><span>${icon('bolt')}48V phantom</span><button class="toggle phantom" role="switch" aria-checked="false" aria-label="Input ${channel} phantom power" data-group="input" data-channel="${channel}" data-field="phantom" disabled></button></div>
  <div class="setting-row"><span>${icon('filter')}High-pass <small>80 Hz</small></span><button class="toggle" role="switch" aria-checked="false" aria-label="Input ${channel} high-pass filter" data-group="input" data-channel="${channel}" data-field="hpf" disabled></button></div>
  <div class="setting-row"><span>PAD <small id="pad-hint-${channel}">Line only</small></span><button class="toggle" role="switch" aria-checked="false" aria-label="Input ${channel} PAD" data-group="input" data-channel="${channel}" data-field="pad" disabled></button></div>
  <div class="mode-block"><div class="mode-label"><span>Mic / Line</span><small>Input type</small></div><div class="segmented" role="group" title="Select microphone or line input" aria-label="Input ${channel} type"><button data-group="input" data-channel="${channel}" data-field="mode" data-value="0" aria-pressed="false" disabled>Mic</button><button data-group="input" data-channel="${channel}" data-field="mode" data-value="1" aria-pressed="false" disabled>Line</button></div></div>`:`
  <div class="setting-row"><span>Signal state</span><small id="signal-${channel}">—</small></div><button class="mute-control" data-group="output" data-channel="${channel}" data-field="mute" aria-pressed="false" disabled>${icon('speaker')}<span>Mute output</span></button>`}</div><div class="channel-footer"><i></i><span id="confirmed-${group}-${channel}">Awaiting device</span><span>CH 0${channel}</span></div></article>`;
}
$('#input-cards').innerHTML=[1,2].map(ch=>card('input',ch)).join('');
$('#output-cards').innerHTML=[1,2].map(ch=>card('output',ch)).join('');

function levelText(group,value){
  return value===null?'—':group==='input'?String(value):((value-255)/2).toFixed(1).replace('-','−');
}
function drawValue(group, channel, value, preview=false){
  const max=group==='input'?66:255;
  $(`#value-${group}-${channel}`).textContent=levelText(group,value);
  $(`#arc-${group}-${channel}`).setAttribute('stroke-dasharray',`${value===null?0:value/max*100} 100`);
  const range=$(`#range-${group}-${channel}`);
  range.value=value??0;
  range.setAttribute("aria-valuetext",value===null?"Unavailable":`${levelText(group,value)} dB`);
  range.style.setProperty('--fill',`${value===null?0:value/max*100}%`);
  $(`#range-state-${group}-${channel}`).textContent=preview?'PREVIEW':value===null?'—':`${levelText(group,value)} dB`;
  $(`#range-state-${group}-${channel}`).classList.toggle('pending-label',preview);
  if(preview) $(`#confirmed-${group}-${channel}`).textContent='Release to apply';
}
function render(next){
  state=next;
  if(!state.connected)renderMeters({valid:false,status:"offline"});
  const active=state.connected && !!state.snapshot;
  const locked=pending || !!state.busy || !active;
  const source=state.demo?'Demo values':active?'Live readback':'Last confirmed';
  $('#demo-badge').hidden=!state.demo;
  $('#side-status').classList.toggle('online',active);
  $('#side-status').innerHTML=`<span class="status-dot"></span>${state.demo?'Demo device':active?'Connected':'Not connected'}`;
  $('#device-ip').textContent=state.device_ip||'—';
  $('#interface-name').textContent=state.interface?`${state.interface} · ${state.local_ip}`:'—';
  $('#top-readback').classList.toggle('live',active);
  $('#top-readback').innerHTML=`<i></i>${pending||state.busy?'Reading device…':state.demo?'Demo workspace':active?'Device synchronized':'Waiting for device'}`;
  $('#connection-button span:last-child').textContent=state.connected?'Connection':'Connect device';
  $('#connection-banner').hidden=active;
  $('#signal-groups').classList.toggle('stale',!active);
  $('#notice').hidden=!state.error;
  $('#notice').textContent=state.error||'';
  $('#refresh-button').disabled=locked;
  $('#disconnect-button').disabled=!state.connected||pending;
  $('#connect-submit').disabled=pending;
  $('#discover-button').disabled=pending||state.demo;
  $('#interface-select').disabled=pending||state.demo;
  $('#ip-address').disabled=pending||state.demo;
  for(const group of ['input','output']){
    const linked=state.snapshot?.[`${group}_link`]??false;
    const link=$(`#${group}-link`);
    link.disabled=locked;
    link.setAttribute('aria-pressed',String(linked));
    link.querySelector('span:last-child').textContent=linked?'Channels linked':`Link ${group}s`;
    for(const ch of [1,2]){
      const channel=state.snapshot?.[`${group}s`]?.[ch-1];
      const element=$(`#card-${group}-${ch}`);
      element.classList.toggle('online',active);
      element.querySelectorAll('button,input').forEach(control=>control.disabled=locked);
      if(editing!==`${group}-${ch}`){
        drawValue(group,ch,channel?.[group==='input'?'gain':'level']??null);
        $(`#confirmed-${group}-${ch}`).textContent=channel?(pending?'Confirming…':source):'Awaiting device';
      }
      if(group==='input'){
        for(const field of ['phantom','hpf','pad']) element.querySelector(`[data-field="${field}"]`).setAttribute('aria-checked',String(channel?.[field]??false));
        const micAvailable=channel?.mode===0 && (!linked || state.snapshot.inputs.every(c=>c.mode===0));
        element.querySelectorAll('[data-field="gain"],[data-field="phantom"]').forEach(control=>{
          control.disabled=locked || !micAvailable;
          control.title=micAvailable?'':'Available in Mic mode';
        });
        element.querySelector('.dial-label').textContent=channel?.mode===1?'PREAMP GAIN · MIC ONLY':'PREAMP GAIN';
        const pad=element.querySelector('[data-field="pad"]');
        const padAvailable=channel?.mode===1 && (!linked || state.snapshot.inputs.every(c=>c.mode===1));
        pad.disabled=locked || !padAvailable;
        pad.title=padAvailable?'Input attenuation':'Available in Line mode';
        $(`#pad-hint-${ch}`).textContent=padAvailable?'Attenuation':'Line only';
        element.querySelectorAll('[data-field="mode"]').forEach(button=>button.setAttribute('aria-pressed',String(channel?.mode===Number(button.dataset.value))));
      }else{
        const mute=element.querySelector('[data-field="mute"]');
        mute.setAttribute('aria-pressed',String(channel?.mute??false));
        mute.querySelector('span:last-child').textContent=channel?.mute?'Unmute output':'Mute output';
        $(`#signal-${ch}`).textContent=channel?(channel.mute?'MUTED':'UNMUTED'):'—';
      }
    }
  }
  $('#feedback-pill').textContent=state.demo?'SIMULATED':active?'CONFIRMED':'OFFLINE';
  $('#feedback-title').textContent=state.demo?'Explore the control surface.':active?'What you see is what’s in use.':state.snapshot?'Your last confirmed settings.':'Ready when you are.';
  $('#feedback-description').textContent=state.demo?'Demo controls are fully interactive. No hardware is connected or changed.':active?'Settings are read back from your DPRO and refreshed automatically. Linked channels move together.':state.snapshot?'The device is offline. These values are retained for reference; reconnect to make changes.':'Parameter values appear after the device confirms them. Connect to see what’s in use.';
  $('#readback-count').innerHTML=state.snapshot?'16 <small>parameters</small>':'— <small>parameters</small>';
  const age=state.updated_at?(Date.now()/1000-state.updated_at):null;
  $('#last-update').textContent=age===null?'—':age<3?'Just now':`${Math.floor(age)}s ago`;
  $('#footer-state').textContent=state.demo?'Demo workspace · hardware disconnected':active?`Connected via ${state.interface} · Auto-refresh on`:'Local workspace · not connected';
  renderEvents(state.events);
}
let lastEvents='';
function renderEvents(events){
  const serialized=JSON.stringify(events);
  if(serialized===lastEvents)return;
  lastEvents=serialized;
  if(!events.length)return;
  $('#activity-list').replaceChildren(...events.slice(0,30).map(event=>{
    const row=document.createElement('div');row.className=`activity-row ${event.kind}`;
    const symbol=document.createElement('span');symbol.className='event-icon';symbol.textContent=event.kind==='error'?'!':'✓';
    const text=document.createElement('span');text.className='event-text';text.textContent=event.text;
    const time=document.createElement('time');time.dateTime=new Date(event.time*1000).toISOString();time.textContent=new Date(event.time*1000).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
    row.append(symbol,text,time);return row;
  }));
}
function toast(message,error=false){
  clearTimeout(toastTimer);$('#toast').textContent=message;$('#toast').classList.toggle('error',error);$('#toast').hidden=false;
  toastTimer=setTimeout(()=>$('#toast').hidden=true,4000);
}
async function fetchJSON(url,options={}){
  const response=await fetch(url,options);
  const data=await response.json();
  if(!response.ok)throw new Error(data.error||'Request failed.');
  return data;
}
async function command(action,data={}){
  if(pending)return null;
  if(!config){toast('The local UI server is not ready. Reload the page.',true);return null;}
  pending=true;
  if(state)render(state);
  $('#dialog-error').hidden=true;
  try{
    const next=await fetchJSON(`/api/${action}`,{method:'POST',headers:{'Content-Type':'application/json','X-DPRO-Token':config.token},body:JSON.stringify(data)});
    render(next);return next;
  }catch(error){
    toast(error.message,true);
    $('#dialog-error').textContent=error.message;$('#dialog-error').hidden=false;
    return null;
  }finally{pending=false;if(state)render(state);}
}
function showConnection(){
  if(state?.local_ip && [...$('#interface-select').options].some(o=>o.value===state.local_ip))$('#interface-select').value=state.local_ip;
  if(state?.device_ip)$('#ip-address').value=state.device_ip;
  $('#dialog-error').hidden=true;
  $('#connection-dialog').showModal();
  if(!state?.demo && !state?.connected)discoverSelectedAdapter();
}
['network-nav','manage-connection','connection-button','banner-connect'].forEach(id=>$(`#${id}`).addEventListener('click',showConnection));
$('#close-dialog').addEventListener('click',()=>$('#connection-dialog').close());
$('#connection-dialog').addEventListener('click',event=>{if(event.target===$('#connection-dialog')){const r=event.target.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)event.target.close();}});
$('#connection-form').addEventListener('submit',async event=>{
  event.preventDefault();
  const next=await command('connect',{local_ip:$('#interface-select').value,device_ip:$('#ip-address').value.trim()});
  if(next){$('#connection-dialog').close();toast(next.demo?'Demo workspace ready.':'Connected. Current settings read from DPRO.');}
});
$('#disconnect-button').addEventListener('click',async()=>{if(await command('disconnect'))$('#connection-dialog').close();});
$('#refresh-button').addEventListener('click',async()=>{if(await command('refresh'))toast(state.demo?'Demo values refreshed.':'Device values refreshed.');});
async function discoverSelectedAdapter(){
  if(pending || state?.demo || !$('#interface-select').value)return;
  const selected=$('#interface-select').value;
  $('#ip-address').value='';
  $('#discovery-results').textContent='Discovering DPRO on this adapter…';
  const result=await command('discover',{local_ip:selected});
  if($('#interface-select').value!==selected)return;
  $('#discovery-results').replaceChildren();
  if(!result)return;
  if(!result.candidates.length){const note=document.createElement('span');note.textContent='No DPRO found. Check the Ethernet connection and allow DPRO Control in macOS Local Network settings, then retry. You can also enter the address manually.';$('#discovery-results').append(note);}
  if(result.candidates.length===1){
    $('#ip-address').value=result.candidates[0];
    const note=document.createElement('span');note.textContent='DPRO found — address filled in automatically.';$('#discovery-results').append(note);
  }
  for(const ip of result.candidates){const button=document.createElement('button');button.type='button';button.textContent=ip;button.addEventListener('click',()=>$('#ip-address').value=ip);$('#discovery-results').append(button);}
}
$('#discover-button').addEventListener('click',discoverSelectedAdapter);
$('#interface-select').addEventListener('change',discoverSelectedAdapter);
$('#signal-groups').addEventListener('click',async event=>{
  const button=event.target.closest('button[data-field]');
  if(!button||button.disabled)return;
  const {group,field}=button.dataset, channel=Number(button.dataset.channel);
  let value;
  if(field==='link')value=!state.snapshot[`${group}_link`];
  else if(button.dataset.step)value=Math.min(group==='input'?66:255,Math.max(0,state.snapshot[`${group}s`][channel-1][field]+Number(button.dataset.step)));
  else if(field==='mode')value=Number(button.dataset.value);
  else value=!state.snapshot[`${group}s`][channel-1][field];
  const result=await command('set',{group,channel,field,value});
  if(result&&field==='link')toast(value?`${group==='input'?'Inputs':'Outputs'} linked. Channel 2 now matches channel 1.`:'Channels can now be adjusted independently.');
});
$('#signal-groups').addEventListener('input',event=>{
  if(event.target.type!=='range')return;
  const {group,channel}=event.target.dataset;
  editing=`${group}-${channel}`;
  drawValue(group,channel,Number(event.target.value),true);
});
$('#signal-groups').addEventListener('change',async event=>{
  if(event.target.type!=='range')return;
  const {group,channel,field}=event.target.dataset;
  const value=Number(event.target.value);editing=null;
  await command('set',{group,channel:Number(channel),field,value});
});
$('#signal-groups').addEventListener('pointercancel',()=>{editing=null;if(state)render(state);});
async function poll(){
  try{render(await fetchJSON('/api/state'));}
  catch(error){if(state)render({...state,connected:false,busy:null,error:'Connection to the app was interrupted. Quit and reopen DPRO Control.'});}
  setTimeout(poll,800);
}
async function boot(){
  try{
    config=await fetchJSON('/api/config');
    const adapters=config.interfaces;
    const select=$('#interface-select');
    for(const adapter of adapters){const option=document.createElement('option');option.value=adapter.ip;option.textContent=`${adapter.name} · ${adapter.ip}`;select.append(option);}
    const preferred=adapters.find(a=>a.ip.startsWith('169.254.'))||adapters[0];
    if(preferred)select.value=preferred.ip;
    if(!adapters.length){const option=document.createElement('option');option.textContent='No IPv4 interface available';option.value='';select.append(option);}
    await poll();
    pollMeters();
  }catch(error){$('#notice').hidden=false;$('#notice').textContent='Unable to start the control surface. Quit and reopen DPRO Control.';}
}
boot();
