# Attribution and third-party components

DPRO Control — Independent Edition is created by **Loud and Beyond**.
The project's original controller/UI/host source and documentation are under
the MIT license in `LICENSE`. Preserve that notice when sharing or adapting it.

The native app bundles CPython 3.14.6, governed by the Python Software
Foundation license and the component notices reproduced in
`third-party/PYTHON-LICENSE.txt`. PyInstaller 6.22.3 packages the runtime;
its license and bootloader exception are reproduced in
`third-party/PYINSTALLER-COPYING.txt`. Those components retain their own terms.
The build also uses Apple system frameworks (AppKit and WebKit) supplied by macOS.

Neutrik and Dante are names/trademarks of their respective owners. Their use
identifies supported hardware and its audio ecosystem; it does not imply
sponsorship, certification or endorsement. This is an independent project.
No official controller executables, firmware, extracted QML or capture archives
are included in this repository. The interface illustration is drawn in CSS;
the project icon is drawn by the project's Swift renderer.

The public Bonjour test fixture is derived from observed traffic with device
instance/MAC identifiers anonymized. The UI screenshot is explicitly demo mode.
